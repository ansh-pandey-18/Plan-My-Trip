#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Structure to represent a hotel room
typedef struct {
    int roomNumber;
    char guestName[50];
    int isOccupied;
} Room;

// Function prototypes
void displayMenu();
void displayRooms(Room rooms[], int numRooms);
void bookRoom(Room rooms[], int numRooms);
void checkOut(Room rooms[], int numRooms);
void displayMenu() {

    printf("1. Display Rooms\n");
    printf("2. Book a Room\n");
    printf("3. Check Out\n");
    printf("4. Exit\n");
}

void displayRooms(Room rooms[], int numRooms) {
    printf("\n===== Room Status =====\n");
    for (int i = 0; i < numRooms; i++) {
        printf("Room %d: %s\n", rooms[i].roomNumber, rooms[i].isOccupied ? rooms[i].guestName : "Available");
    }
}

void bookRoom(Room rooms[], int numRooms) {
    int roomNumber;
    printf("Enter the room number to book: ");
    scanf("%d", &roomNumber);

    if (roomNumber < 1 || roomNumber > numRooms) {
        printf("Invalid room number.\n");
        return;
    }

    if (rooms[roomNumber - 1].isOccupied) {
        printf("Room is already occupied.\n");
    } else {
        printf("Enter guest name: ");
        scanf("%s", rooms[roomNumber - 1].guestName);
        rooms[roomNumber - 1].isOccupied = 1;
        printf("Room booked successfully.\n");
    }
}

void checkOut(Room rooms[], int numRooms) {
    int roomNumber;
    printf("Enter the room number to check out: ");
    scanf("%d", &roomNumber);

    if (roomNumber < 1 || roomNumber > numRooms) {
        printf("Invalid room number.\n");
        return;
    }

    if (rooms[roomNumber - 1].isOccupied) {
        printf("Checking out %s from Room %d.\n", rooms[roomNumber - 1].guestName, roomNumber);
        rooms[roomNumber - 1].isOccupied = 0;
        strcpy(rooms[roomNumber - 1].guestName, "");
    } else {
        printf("Room is not occupied.\n");
    }
}

void bookhotel(){
printf("\n===== Hotel Booking System =====\n");
       int z;
       while(z>8){
   printf("HOTEL BOOKING\n\n\n");
   printf("enter the hotel number you want to stay in :\n\n");
   printf("1: THE GRAND IMPERIAL\n");
   printf("2: TAJ PALACE\n");
   printf("3: RADISSON BLU\n");
   printf("4: THE GALAXY SUITES\n");
   printf("5: ITC MAURYA\n");
   printf("6: THE LUXUS HOTELS\n");
   printf("7: HOTEL RATAN VILLAS\n");
   printf("8: THE HAYATT CENTTRIC\n\n");
   scanf("%d",&z);
   if(z>=9){
    printf("invalid choice\n\n");
    printf("try again\n\n\n");
   }
   }


    const int numRooms = 10;
    Room rooms[numRooms];

    // Initialize rooms
    for (int i = 0; i < numRooms; i++) {
        rooms[i].roomNumber = i + 1;
        rooms[i].isOccupied = 0;
        strcpy(rooms[i].guestName, "");
    }

    int choice;

    do {

        displayMenu();
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                displayRooms(rooms, numRooms);
                break;
            case 2:
                bookRoom(rooms, numRooms);
                break;
            case 3:
                checkOut(rooms, numRooms);
                break;
            case 4:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);


}

struct discount
{
    int discountAmount;
    char couponName;
 };
       //COUPON CODE
void couponCode()
{
     int i,flag,j;
    int count1=0,count2=0;

    printf("ENTER 3 LETTER COUPON CODE:\n");

    char userInputCoupon[3];
    char coupon1[3]="ABC";
    scanf("%s",&userInputCoupon);

    while (userInputCoupon[count2] != '\0'){
        count2++;}

    for (i=0;i<=3-count2;i++)
    {
        for (j=i;j<i+count2;j++)
    {
        flag = 1;
        if (coupon1[j]!=userInputCoupon[j-i])
    {
        flag = 0;
        break;
    }}
        if (flag == 1)
        break;
    }
    if (flag == 1){
         printf("COUPON SUCCESSFULLY APPLIED!!\n");
         return 0;}
    else flag==0;

    char coupon3[3]="XYZ";
    while (userInputCoupon[count2] != '\0'){
        count2++;}

    for (i=0;i<=3-count2;i++)
    {
        for (j=i;j<i+count2;j++)
    {
        flag = 1;
        if (coupon3[j]!=userInputCoupon[j-i])
    {
        flag = 0;
        break;
    }}
        if (flag == 1)
        break;
    }
     if (flag == 1)
        {
         printf("COUPON SUCCESSFULLY APPLIED!!\n");
         return 0;
         }
    else flag==0;

    char coupon4[3]="MNO";

    while (userInputCoupon[count2] != '\0'){
        count2++;}

    for (i=0;i<=3-count2;i++)
    {
        for (j=i;j<i+count2;j++)
    {
        flag = 1;
        if (coupon4[j]!=userInputCoupon[j-i])
    {
        flag = 0;
        break;
    }}
        if (flag == 1)
        break;
    }
    if (flag == 1)
        printf("COUPON SUCCESSFULLY APPLIED!!\n");
    else
        printf("COUPON INVALID\n");
return 0;
}

          // BANK CARD DISCOUNT
void bankCards()
{
    int n;
char bankName;
int accountNo,pin;
   printf("\n");
   printf("TO CHECK AVAILABLE BANK OFFERS, PRESS 1\n");

   printf("TO APPLY BANK OFFERS, PRESS 2\n");
   printf("TO EXIT THE WINDOW PRESS 3\n");
   printf("\n");
   printf("\n");

    while(n!=3){
            printf("enter your choice:\n");
            scanf("%d",&n);

        switch(n)
        {
    case 1:
        printf("offer 1\n");
        printf("10%% INSTANT DISCOUNT UP TO INR 2000 ON SBI CREDIT AND DEBIT CARDS. NO EMI TRXNS\n");

        printf("\n");
        printf("offer 2\n");
        printf("FLAT INR 2500 ON CITI BANK DEBIT CARD. MIN TOUR BUDGET INR 60000.\n");
        printf("\n");
        break;

    case 2:

    printf("enter bank name (SBI/CITI BANK)\n");
    scanf("%s",&bankName);

    printf("enter account number\n");
    scanf("%d",&accountNo);

    printf("enter 4 digit pin\n");
    scanf("%d",&pin);

    printf("DISCOUNT APPLIED SUCCESSFULLY\n");
    printf("\n");
    break;

    case 3: printf("exiting window");
    break;

    default: printf("INVALID CHOICE\n");
    }
}


}


 void applydiscount(){
 int choice;
    while(choice!=3)
        {
printf("\nABC DISCOUNT SYSTEM");

printf("\n1: APPLY COUPON CODE");
printf("\n2: BANK CREDIT AND DEBIT CARDS");

printf("\n3: EXIT THIS WINDOW");
printf("\n");
printf("\n");

printf("\nENTER YOUR CHOICE : ");
scanf("%d",&choice);

switch(choice)
{
 case 1:
     couponCode();
     break;

 case 2:
     bankCards();
     break;

 case 3:
     printf("EXITING DISCOUNT WINDOW\n\n\n");
     break;

 default:
     printf("INVALID CHOICE\n");
     printf("PLEASE TRY AGAIN");
}
}
 }

typedef struct TourFeedback {
    char name[50];
    int rating;
    char comments[200];
}tf;

void collectTourFeedback(tf *tourFeedback);
void displayTourFeedback(const tf *tourFeedback);

void collectTourFeedback(tf *tourFeedback)
 {
    printf("Enter your name: ");
    fgets(tourFeedback->name, sizeof(tourFeedback->name), stdin);
    tourFeedback->name[strcspn(tourFeedback->name, "\n")] = '\0';
    printf("Rate your tour experience (1 to 5): ");
    scanf("%d", &tourFeedback->rating);
    while (getchar() != '\n');

    printf("Enter your comments about the tour (max 200 characters):\n");
    fgets(tourFeedback->comments, sizeof(tourFeedback->comments), stdin);
    tourFeedback->comments[strcspn(tourFeedback->comments, "\n")] = '\0';
    printf("Thank you!\n Your response has been recorded.");
}

void displayTourFeedback(const tf *tourFeedback)
{
    printf("\n\n\nTour Feedback Summary:\n");
    printf("Name: %s\n", tourFeedback->name);
    printf("Rating: %d\n", tourFeedback->rating);
    printf("Comments: %s\n", tourFeedback->comments);
}
leavetestimonial(){
 tf userTourFeedback;

    printf("Welcome to our Tour Agency Feedback System\n");

    collectTourFeedback(&userTourFeedback);

    displayTourFeedback(&userTourFeedback);

}
void restaurant_choice();  //Function prototypes
int choice();
int order_item();
void calculate_bill();
void Pay_Bill();
int main();
int token_number = 0;
int tokensum[50];
int payment_counter=0;
int flag=0;

    void restaurant_choice()
    {
        int rest_ch;
    printf("The famous Restaurants of the city are:\n");
    printf("1. Domino's Pizza\n");
    printf("2. KFC\n");
    printf("3. Haldiram's\n");
    printf("4. Bikanervala\n");
    printf("5. McDonald's\n");
    printf("\n\nPlease Enter your choice\n");
    scanf("%d",&rest_ch);
    if(rest_ch>=1&&rest_ch<=5)
    {
    printf("\n\nNamaskaram!\nWelcome to our Restaurant \n\n");
    }
    else
        printf("\n\nInvalid choice. Please try again\n");
    }


    int choice()
    {

    printf("Select any of them - \n");
    printf("1.   New order\n");
    printf("2.   Bill payment\n");
    printf("3.   Exit\n");

    printf("\n\n     Enter Your Choice: ");
    int n;
    scanf("%d",&n);
    return n;
    }

    int order_item ()
    {
    int itemID[10];
    int itemqty[10];
    int Bill[10];
    int decision,itemcount=0;
    work:
    printf("\n\t\t\t\tFOOD MENU\n\t\t\t\t\n");
    printf("\n\tRICE :\n\n");
    printf("\t1. Bassmati Rice ...................... 120/=\t  \n");
    printf("\t2. Jeera Rice ..........................  40/=\n");
    printf("\t3. Green Peas Pulao ...........................  70/=\t \n");
    printf("\t4. Saffron Rice ..........  90/=\t \n");
    printf("\t\t\t\t\t\t\t \n\n\tDAAL:\n\n");
    printf("\t5. Moong Daal ...................  90/=\n");
    printf("\t6. Urad Daal ....................  65/=\n");
    printf("\n\tBIRYANI :\n\t\t\t\t\t\t\t \n");
    printf("\t7. Egg Biryani ........................  65/=\t  \n");
    printf("\t8. Royal Gold Biryani ........................... 230/=\t \n");
    printf("\n\t DESSERTS :\n\n");
    printf("\t9.  Ice cream ........................ 25/=\n");
    printf("\t10. Pastry   ........................ 25/=\n");
    printf("\n\n\tOrder your dish: (Enter 0 to finish order)\n");
    for(;;)
    {
        itemcount++;
        printf("\t Enter Food ID: ");
        scanf("%d",&itemID[itemcount-1]);
        if(itemID[itemcount-1]==0)
        {
            break;
        }
        if(itemID[itemcount-1]>=1&&itemID[itemcount-1]<=10)
        {
        printf("\t Enter Quantity: ");
        scanf("%d",&itemqty[itemcount-1]);
        }
        else
            printf("Invalid Food ID.\nPlease Try Again\n");

    }
   printf("\n\t\tThanks for your order. We are getting ready the dishes.\n\t\tUntil then, have some selfies with friends. Enjoy!\n\n\t\t  <Enter 1 to check your bill>\t\t\n\n\t\t<enter (2) to give another order>\n\n\t\t<enter (3) to go to the main menu>\n\n\t\t\tEnter your choice:");
    scanf("%d",&decision);
    printf("\n\n");

    itemcount--;

    if(decision==1)
    {
        calculate_bill(itemID,itemqty,itemcount);
    }

    else if(decision==2)
    {
       goto work;
    }

    else if(decision==3)
    {
        main();
    }
    }


    void calculate_bill (int itemID[],int itemqty[],int itemcount)
    {

    int n;

    int i,sum=0;
    int costs[10]={120,40,70,90,90,65,65,230,25,25};
    char items[10][20]={"Bassmati Rice","Jeera Rice","Green Peas Pulao","Saffron Rice","Moong Daal","Urad Daal","Egg Biryani","Royal Gold Biryani","Ice Cream","Pastry"};
    printf("\n\nYour Bill:\n\n\n\t\tItem(s)\t\t     Quantity\t\t    Cost\n\n\n\n");

    for(i=0;i<itemcount;i++)
    {
        printf("\t%2d. %-16s _\t%-5d piece(s) _ %7d\n",i+1,items[itemID[i]-1],itemqty[i],itemqty[i]*costs[itemID[i]-1]);
        sum=sum+(costs[itemID[i]-1]*itemqty[i]);
    }

    printf("\n\n\n\n\t\t\t\t\t\t\t  Total = %d\n\n\n\n",sum);
    token_number ++;
    tokensum[token_number]=sum;
    printf("\tYour token number is %d. Use this token while paying the bill.\n\n\n\n\n\t\t\t<enter (1) to give another order>\n\n\t\t\t<enter (2) to go to the main menu>\n\n\t\n\t\t\tEnter your choice: ",token_number);
    scanf("%d",&n);
    printf("\n\n\n");
    if(n==1)
    {
        order_item();
    }
    else if(n==2)
    {
        main();

    }

}


    void Pay_Bill()
    {

    int k,i;
    int amount,remaining_amount;
    redo:
    payment_counter++;
    printf("\n\n\n\t\t\tEnter your token number: ");
    scanf("%d",&k);
    printf("\t\t\tYour Total Bill is = %d",tokensum[k]);
    work:
            printf("\n\t\t\tPay your bill: ");
            scanf("%d",&amount);
    remaining_amount = amount-tokensum[k];
    if(remaining_amount == 0)
    {
        printf("\n\t\tThanks for your payment. Have a great day!\n");
    }
    else if (remaining_amount<0)
    {
        printf("\n\t\t\tAmount is not sufficient. :(\n\t\tPlease pay the fair price of your bill\n");
        goto work;
    }
    else
    {
        printf("\n\n\n\t\tHere is change for your remaing amount: (%d - %d) = %d Rupees\n\t\t  ",amount,tokensum[k],remaining_amount);

            for(i=0;i<19;i++)
            {
                printf(" ");
            }
            if(remaining_amount>=2000 )
                {
                    printf("\n\t\t 2000 Rupees note(s) = %d\n",remaining_amount/2000);
                remaining_amount=remaining_amount%2000;
                }
            if(remaining_amount>=500 && remaining_amount<2000)
            {
                printf("\n\t\t 500 Rupees note(s) = %d\n",remaining_amount/500);
            remaining_amount=remaining_amount%500;
            }
            if(remaining_amount>=100 && remaining_amount<500)
            {
                printf("\n\t\t 100 Rupees note(s) = %d\n",remaining_amount/100);
            remaining_amount= remaining_amount%100;
            }
            if(remaining_amount>=50 && remaining_amount<100)
            {
                printf("\n\t\t  50 Rupees note(s) = %d\n",remaining_amount/50);
            remaining_amount=remaining_amount%50;
            }
             if(remaining_amount>=10 && remaining_amount<50)
            {
                printf("\n\t\t  10 Rupees note(s) = %d\n",remaining_amount/10);
            remaining_amount=remaining_amount%10;
            }
            if(remaining_amount>=5 && remaining_amount<10)
            {
                printf("\n\t\t   5 Rupees note(s) = %d\n",remaining_amount/5);
            remaining_amount=remaining_amount%5;
            }
            if(remaining_amount>=2 && remaining_amount<5)
            {
                printf("\n\t\t   2 Rupees note(s) = %d\n",remaining_amount/2);
            remaining_amount=remaining_amount%2;
            }
            if(remaining_amount>=1 && remaining_amount<2)
            {
                printf("\n\t\t   1 Rupees note(s) = %d\n",remaining_amount/1);
            remaining_amount=remaining_amount%1;
            }

            printf("\t\t  ");
            for(i=0;i<19;i++)
            {
                printf("_");
            }

        printf("\n\n\n\n\n\t\t\tThanks for your payment.\n\t\t\t    Have a great day!\n");


    }
    printf("\n\n\t\t\t<Enter (1) to pay another bill.>\n\t\t\t<Enter (2) to go back main menu>\n\n\n\t\t\tEnter your choice: \t");
    int n;
        scanf("%d",&n);
        if(n==2)
        {
            main();
        }
        else if(n==1)
        {
           goto redo;
        }

    }
findrestaurant(){
    if(flag==0)
        {
    restaurant_choice();
    flag=1;
        }
    int k;
    k = choice();

    if(k==1)
    {
        order_item();
    }

    else if(k==2)
    {
        Pay_Bill();
    }

    else
    {

        printf("\n\n\t\tOrders Recieved in this session:  %d\n\n",token_number);
        printf("\t\tBills paid in this session      : %d\n\n",payment_counter);
        if(payment_counter<token_number)
        {
            printf("\t\tBills Yet to pay          : %d\n\n\n",token_number-payment_counter);
            printf("Please pay your remaining bills!");
            }
        else
        {
            printf("Thanks you!\n Please visit our restaurant again.");
        }
    }

}
struct rail
{
    char name[30];
    int age;
    char gender[30];
    int aadhar_card[30];
};
struct air
{
    char name[30];
    int age;
    char gender[30];
    int aadhar_card[30];
    int passport_number[30];
};
struct road
{
    char name[30];
    int age;
    char gender[30];
    int aadhar_card[30];
};
int amounttotal(int buscharges)
{
    int total;
    int discount =2000;
    total = buscharges-discount;
    return total;
}
void train()
{
    int o, z;
    float bill;
    int ac_sleeper_charge = 20000;
    int sleeper_charge = 17000;
    int train_charge = 4000;
    printf("ENTER NUMBER OF PASSENGERS\n");
    scanf("%d", &o);
    struct rail t[o];
    struct rail *trc = t;
    for (z = 0; z < o; z++)
    {
        printf("ENTER NAME\n");
        scanf("%s", trc[z].name);
        printf("ENTER AGE\n");
        scanf("%d", &trc[z].age);
        printf("ENTER YOU GENDER MALE FEMALE OTHER\n");
        scanf("%s", trc[z].gender);
         printf("ENTER YOUR AADHAR CARD NUMBER\n");
        scanf("%d", trc[z].aadhar_card);
    }
    int budget, A;
    printf("ENTER YOUR BUDGET\n");
    scanf("%d", &budget);
    if (budget >= 20000)
    {
        printf("YOU ARE ELIGIBLE FOR AC SLEEPER TRAIN\n");
        bill = amounttotal(ac_sleeper_charge);
        printf("YOUR TOTAL TRANSPORTATION CHARGE IS: %f", bill);
         printf("\n");
    transportsystem();
    }
    else if (budget>= 15000&&budget<20000)
    {
        printf("YOU ARE ELIGIBLE FOR SLEEPER TRAIN\n");
        bill = amounttotal(sleeper_charge);
        printf("your total transportation charges: %f", bill);
         printf("\n");
    transportsystem();
    }
    else
    {
        printf("YOU ARE ELIGIBLE FOR SEATER TRAIN\n");
        bill = amounttotal(train_charge);
        printf("your total transportation charges: %f\n", bill);
         printf("\n");
    transportsystem();
    }
}

void airplane()
{
    int w, z;
     float bill;
    int buissness_class = 60000;
    int economic_class = 35000;
    printf("ENTER NUMBER OF PASSENGERS\n");
    scanf("%d", &w);
    struct air a[w];
    struct air *arc = a;
    for (z = 0; z < w; z++)
    {
        printf("ENTER NAME\n");
        scanf("%s", arc[z].name);
        printf("ENTER AGE\n");
        scanf("%d", &arc[z].age);
        printf("ENTER YOUR GENDER MALE FEMALE OTHER\n");
        scanf("%s", arc[z].gender);
         printf("ENTER YOUR AADHAR CARD NUMBER\n");
        scanf("%d", arc[z].aadhar_card);
         printf("ENTER YOUR PASSPORT NUMBER\n");
        scanf("%d", arc[z].passport_number);
    }
        int budget, A;
    printf("ENTER YOUR BUDGET\n");
    scanf("%d", &budget);
    if (budget >= 60000)
    {
        printf("YOU ARE ELIGIBLE FOR BUISSNESS CLASS\n");
        bill = amounttotal(buissness_class);
        printf("YOUR TOTAL TRANSPORTATION CHARGE IS: %f", bill);
         printf("\n");
    transportsystem();
    }
    else if (budget>= 35000&&budget<60000)
    {
        printf("YOU ARE ELIGIBLE FOR ECONOMIC CLASS\n");
        bill = amounttotal(economic_class);
        printf("YOUR TOTAL TRANSPORTATION CHARGE IS: %f", bill);
         printf("\n");
    transportsystem();
    }
    else
    {
        printf("YOU ARE NOT ELIGIBLE FOR AIRPLANE\n");
printf("\n");
    transportsystem();
    }
}
void bus()
{
    int x, z;
    float bill;
    int ac_sleeper_charge = 20000;
    int sleeper_charge = 17000;
    int bus_charge = 10000;
    printf("ENTER NUMBER OF PASSENGERS\n");
    scanf("%d", &x);
    struct road b[x];
    struct road *brc = b;
    for (z = 0; z < x; z++)
    {
        printf("enter name\n");
        scanf("%s", brc[z].name);
        printf("enter age\n");
        scanf("%d", &brc[z].age);
        printf("ENTER YOUR GENDER MALE FEMALE OTHER\n");
        scanf("%s", brc[z].gender);
         printf("ENTER YOUR AADHAR CARD NUMBER\n");
        scanf("%d", brc[z].aadhar_card);
    }
    int budget, A;
    printf("ENTER YOUR BUDGET\n");
    scanf("%d", &budget);
    if (budget >= 20000)
    {
        printf("YOU ARE ELIGIBLE FOR AC SLEEPER BUS\n");
        bill = amounttotal(ac_sleeper_charge);
        printf("YOUR TOTAL TRANSPORTATION CHARGE IS: %f", bill);
         printf("\n");
    transportsystem();
    }
    else if (budget>= 15000&&budget<20000)
    {
        printf("YOU ARE ELIGIBLE FOR SLEEPER BUS\n");
        bill = amounttotal(sleeper_charge);
        printf("YOUR TOTAL TRANSPORTATION CHARGE IS: %f", bill);
         printf("\n");
    transportsystem();
    }
    else
    {
        printf("YOU ARE ELIGIBLE FOR SEATER BUS\n");
        bill = amounttotal(bus_charge);
        printf("YOUR TOTAL TRANSPORTATION CHARGE IS: %f\n", bill);
        printf("\n");
    transportsystem();
    }
}
// Defining Structure
typedef struct passenger_info {
	char name[20];
	char gen[6];
	int age;
	struct passenger_info* link;
} info;
info* start = NULL;

// Declaring Function Used
// In This Program
void heading();
void details();
void inter();
void india();
void receipt();
void tour_place();


// Global variables
int p, amount;
char choice1[60], place[30], date[20];
char pick[40];

// Driver Code



void booktour()
{
   int tour_type;

	// Calling heading() function
	heading();
	printf("ENTER YOUR PICKUP CITY: ");
	gets(pick);

	// Taking Choice From User
	printf("\t\t\t\t1. INTERNATIONAL "
		"TOUR\n");
	printf("\t\t\t\t2. INDIAN TOUR \n");
	printf("\t\t\t\tENTER YOUR CHOICE: ");
	scanf("%d", &tour_type);

	switch (tour_type) {
	// Calling inter() function
	case 1:
		inter();
		// Calling details() function
	    details();
		// Calling receipt() function
	    receipt();
		break;
	// Calling india() function
	case 2:
		india();
		// Calling details() function
	    details();
		// Calling receipt() function
	    receipt();

		break;

	default:
		printf("Enter Right Choice...");
		break;
	}
}
// Function To Take Package
// Choice From India
void india()
{
	int ch;

	// Clearing Screen
	system("cls");

	// Calling heading() function
	heading();
	strcpy(choice, "Indian Tour Package");
	printf("\t\t\t\t1. Shimla Tour  "
		"6 Days 7 Nights\n");
	printf("\t\t\t\t2. Kashmir Tour  "
		"5 Days 4 Nights\n");
	printf("\t\t\t\t3. Kolkata Tour  "
		"11 Days 10 Nights\n");
	printf("\t\t\t\t4. Mumbai Tour "
		"6 Days 5 Nights\n");
	printf("\t\t\t\t5. Gurgaon Tour  "
		"8 Days 7 Nights\n");
	printf("\t\t\t\t6. Delhi Tour "
		"4 Days 5 Nights\n");
	printf("\t\t\t\t7. Ahmedabad Tour  "
		"5 Days 7 Nights\n");
	printf("\t\t\t\t7. Punjab Tour "
		"6 Days 6 Nights\n");
	printf("\t\t\t\t9. Agra Tour "
		"9 Days 10 Nights\n");
	printf("\t\t\t\t10. Tamilnadu Tour  "
		"4 Days 3 Nights\n");

	printf("\t\t\t\tENTER CHOICE: ");
	scanf("%d", &ch);
	if (ch == 1) {
		strcpy(place, "Shimla Tour");
		// function for restuarant and travels and  apply the same for all below cities..
	}
	else if (ch == 2) {
		strcpy(place, "Kashmir Tour");
	}
	else if (ch == 3) {
		strcpy(place, "Kolkata Tour");
	}
	else if (ch == 4) {
		strcpy(place, "Mumbai Tour");
	}
	else if (ch == 5) {
		strcpy(place, "Gurgaon Tour");
	}
	else if (ch == 6) {
		strcpy(place, "Delhi Tour");
	}
	else if (ch == 7) {
		strcpy(place, "Ahmedabad Tour");
	}
	else if (ch == 8) {
		strcpy(place, "Punjab Tour");
	}
	else if (ch == 9) {
		strcpy(place, "Agra Tour");
	}
	else if (ch == 10) {
		strcpy(place, "Tamilnadu Tour");
	}

	else{
		printf("Enter Correct Choice...");
		void india();
}
}

// Function To Take Tour Choice
// From International....
void inter()
{
	int ch;

	// Clearing Screen
	system("cls");

	// Calling heading() function
	heading();
	strcpy(choice1, "International Tour");
	printf("\t\t\t\t1. England Tour  "
		"6 Days 7 Nights \n");
	printf("\t\t\t\t2. Thailand Tour  "
		"5 Days 4 Nights \n");
	printf("\t\t\t\t3. New York Tour  "
		"11 Days 10 Nights \n");
	printf("\t\t\t\t4. Switzerland Tour  "
		"6 Days 5 Nights \n");
	printf("\t\t\t\t5. Germany Tour  "
		"8 Days 7 Nights \n");
	printf("\t\t\t\t6. Norway Tour  "
		"4 Days 5 Nights \n");
	printf("\t\t\t\t7. Italy Tour  "
		"5 Days 7 Nights \n");
	printf("\t\t\t\t8. Dubai Tour  "
		"6 Days 6 Nights \n");
	printf("\t\t\t\t9. Australia Tour  "
		"9 Days 10 Nights \n");
	printf("\t\t\t\t10. Japan Tour  "
		"4 Days 3 Nights \n");
	printf("ENTER CHOICE:");
	scanf("%d",&ch);

	if (ch == 1) {
		strcpy(place, "England Tour");
		// function for restruant and travels...
		// apply the same for all below mentioned cities...
	}
	else if(ch==2){
		strcpy(place, "Thailand Tour");
	}
	else if (ch == 3) {
		strcpy(place, "New York Tour");
	}
	else if (ch == 4) {
		strcpy(place, "Switzerland Tour");
	}
	else if(ch==5){
		strcpy(place, "Norway Tour");
	}
	else if(ch==6){
		strcpy(place, "Italy Tour");
	}
	else if(ch==7){
		strcpy(place, "Dubai Tour");
	}
	else if(ch==8){
		strcpy(place, "Australia Tour");
	}
	else if(ch==9){
		strcpy(place, "Japan Tour");
	}
	else if(ch==10){
		strcpy(place, "Thailand Tour");
	}

	else{
		printf("Enter Correct Choice...");
		void inter();
}
}

// Function To Take Passenger Details
void details()
{
	int i, age;
	char val[20], gen[6];

	// Clearing Screen
	system("cls");

	// Calling heading() function
	heading();
	printf("\t\t\t\tENTER NUMBER OF "
		"PERSONS: ");
	scanf("%d", &p);
	printf("\t\t\t\tENTER DATE "
		"(DD/MM/YY): ");
	fflush(stdin);
	gets(date);
	for (i = 1; i <= p; i++) {
		system("cls");
		heading();
		printf("\t\t\t\tEnter The %dth "
			"person Name: ",
			i);
		fflush(stdin);
		gets(val);
		printf("\t\t\t\tEnter The %dth "
			"Passenger Gender: ",
			i);
		fflush(stdin);
		gets(gen);
		printf("\t\t\t\tEnter The %dth "
			"Passenger Age: ",
			i);
		fflush(stdin);
		scanf("%d", &age);

		// Calling add_detail() function
		add_detail(val, gen,age);
	}
}

// Function to add details of
// passengers
void add_detail(char Name[20],
			char Gen[6], int b)
{
	info *newptr = NULL, *ptr;
	newptr = (info*)malloc(sizeof(info));
	strcpy(newptr->name, Name);
	strcpy(newptr->gen, Gen);
	newptr->age = b;
	newptr->link = NULL;
	if (start == NULL)
		start = newptr;
	else {
		ptr = start;
		while (ptr->link != NULL)
			ptr = ptr->link;
		ptr->link = newptr;
	}
}

// Function For Printing Receipt
void receipt()
{
	int i, b;
	info* ptr = start;
	system("cls");
	heading();
	printf("\n\t\t\t\t**TAKE SCREENSHOT "
		"FOR FURTHER USE**\n");
	for (i = 1; i <= p; i++) {
		printf("\t\t\t\t%dst Passenger "
			"Name: ",
			i);
		puts(ptr->name);
		printf("\t\t\t\t%dst Passenger "
			"Gender: ",
			i);
		puts(ptr->gen);
		printf("\t\t\t\t%dst Passenger "
			"Age: %d\n\n",
			i, ptr->age);
		ptr = ptr->link;
	}
	printf("\t\t\t\tSelected Type: ");
	puts(choice1);
	printf("\t\t\t\tPackage: ");
	puts(place);
	printf("\t\t\t\tDate: ");
	puts(date);
	b = amount * p;
	printf("\t\t\t\tTotal Amount: %d", b);
	printf("\n\t\t\t\t**THANK YOU FOR "
		"REGISTRATION**");
}

// Function For Printing Heading...
void heading()
{
	printf("\t\t\t\t***TOUR "
		"MANAGEMENT SYSTEM***\n");
	printf("\t\t\t***WELCOME TO THE TOUR MANAGEMENT WINDOW "
		"*\n\n");
}

void transportsystem(){
printf("1 FOR TRAIN\n2 FOR AIRPLANE\n3 FOR BUS\n4 EXIT\n");
    int m;
    scanf("%d", &m);
    switch (m)
    {
    case 1:
        train();
        break;
    case 2:
        airplane();
        break;
    case 3:
        bus();
        break;
    case 4:
        printf("EXIT\n");
        break;
    default:
        printf("INVALID\n");
    }
    }
    int main() {
    int choice;

    while (1) {
        printf("Tour and Travel Service Menu:\n");
        printf("1. Book a Tour\n");
        printf("2. Access Transport System\n");
        printf("3. Book a Hotel\n");
        printf("4. Find Restaurants\n");
        printf("5. Apply Discounts\n");
        printf("6. Leave a Testimonial\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
        case 1:
            booktour();
            break;
            case 2:
         transportsystem();
            break;
            case 3:
                bookhotel();
                break;
            case 4:
                findrestaurant();
                break;
            case 5:
                applydiscount();
                break;
            case 6:
                leavetestimonial();
            case 7:
                return;

            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
